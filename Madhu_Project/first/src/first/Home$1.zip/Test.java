package first;

import java.util.*;
public class Test {

	public static void main(String[] args) {
		String str = "",s="";
		
		if(str.equals(s))
			System.out.println("null");
		else
			System.out.println("not null");
		
	}

}
